<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    //
    public function login(Request $request)
    {
        $this->validateLogin($request);

        if(Auth::attempt($request->only("email","password"))){
            return response()->json([
                "token" => $request->user()->createToken($request->email)->plainTextToken,
                "message" => "Verificado"
            ],200);
        }

        return response()->json([
            "message" => "Acceso denegado"
        ],409);
    }

    public function validateLogin(Request $request)
    {
        return $request->validate([
            "email" => "required|email",
            "password" => "required"            
        ]);
    }

    public function register(Request $request)
    {
       $fields = $request->validate([
            'name' => "required|string",
            "email" => "required|email",
            "password" => "required"
       ]);

       $user = User::create([
            "name" => $fields["name"],
            "email" => $fields["email"],
            "password" => bcrypt($fields["password"])
       ]);

       $token = $user->createToken("myapptoken")->plainTextToken;

       $reponse =[
            "user" => $user,
            "token" => $token
       ];

       return response($reponse);
    }
}
